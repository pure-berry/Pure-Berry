# PUREBERRY

A Pen created on CodePen.

Original URL: [https://codepen.io/Nayla-the-sans/pen/EaPBxaX](https://codepen.io/Nayla-the-sans/pen/EaPBxaX).

